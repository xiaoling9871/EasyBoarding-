## Housing Management service
Postman link is here: https://api.postman.com/collections/24119018-036f4352-0ad6-47f4-be65-89ceff030ebd?access_key=PMAT-01GQQE925VJNZFMBEZRZPFQ4QC