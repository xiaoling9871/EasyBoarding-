package com.example.compositeservice.domain.response;

import com.example.compositeservice.domain.employeeEntity.EmployeeSummaryDto;
import com.example.compositeservice.domain.housingEntity.ResponseReportEMP;
import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HouseDetailHr {
    List<Map<String,Object>> facilitiesInHouse;
    List<ResponseReportEMP> filteredReports;
    List<EmployeeSummaryDto> roommateInfo;


}
