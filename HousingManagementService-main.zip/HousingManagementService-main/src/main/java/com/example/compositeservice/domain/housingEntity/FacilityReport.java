package com.example.compositeservice.domain.housingEntity;

import lombok.*;

import java.sql.Timestamp;
import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class FacilityReport {

    private Integer id;

    private Facility facility;

    private String employeeId;

    private String title ;

    private String description;

    private Timestamp createDate;

    private String status;

    private List<FacilityReportDetail> facilityReportDetails;

}
