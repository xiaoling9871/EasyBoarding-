package com.example.compositeservice.domain.housingEntity;

import lombok.*;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Landlord {

    private Integer id;
    private String firstname;

    private String lastname;


    private String cellphone;


    private String email;

    private List<House> houses;

}
