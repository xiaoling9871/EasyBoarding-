package com.example.compositeservice.domain.employeeEntity;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class Contact {
    private String id;

    private String firstName;

    private String lastName;

    private String cellPhone;

    private String email;

    private String relationship;

    private String type;
}
