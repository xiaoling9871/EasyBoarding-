package com.example.compositeservice.service.remote;

import com.example.compositeservice.domain.housingEntity.Facility;
import com.example.compositeservice.domain.housingEntity.ResponseLandlord;
import com.example.compositeservice.domain.housingEntity.ResponseReportEMP;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(value = "housing-service")
public interface RemoteHousingService {

    @GetMapping(value = "/housing/hr/landlordInfo")
    ResponseLandlord landlordInfo(@RequestParam(name = "houseId")Integer houseId);

    @GetMapping(value = "/housing/hr/houseOccList")
    Map<Integer, Integer> houseOccList();

    @GetMapping(value = "/housing/emp/detail/address")
    String getAddress(@RequestParam(name = "houseId") Integer HouseId);

    @GetMapping(value = "/housing/emp/report/existingReports")
    List<ResponseReportEMP> viewAllReports();

    @GetMapping(value = "/housing/emp/report/existingReportsAuthor")
    List<Map<String, Object>> viewReportsAuthor(@RequestParam(name = "userId") String userId);

    @GetMapping(value = "/housing/hr/facilityInfo")
    List<Facility> viewFacilities(@RequestParam Integer houseId);

    @GetMapping(value = "/housing/hr/facilitySum")
    List<Map<String,Object>> facilitySummary(@RequestParam Integer house_id);
}
