package com.example.compositeservice.domain.response;

import com.example.compositeservice.domain.employeeEntity.EmployeeSummaryDto;
import lombok.*;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HouseDetailsEmp {
     List<EmployeeSummaryDto> roommateInfo;
     String address;

}
