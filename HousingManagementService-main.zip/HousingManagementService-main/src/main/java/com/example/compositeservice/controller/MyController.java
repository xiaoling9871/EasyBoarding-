package com.example.compositeservice.controller;

import com.example.compositeservice.domain.housingEntity.ResponseReportEMP;
import com.example.compositeservice.domain.response.HouseDetailHr;
import com.example.compositeservice.domain.response.HouseDetailsEmp;
import com.example.compositeservice.domain.response.HouseSummaryHr;
import com.example.compositeservice.service.CompositeService;
import com.example.compositeservice.service.remote.RemoteEmployeeService;
import com.example.compositeservice.service.remote.RemoteHousingService;
import com.fasterxml.jackson.databind.util.JSONPObject;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Base64;
import java.util.List;

@RestController
@Api("HousingManagement Service endpoint")
public class MyController {
    private RemoteHousingService housingService;
    private RemoteEmployeeService employeeService;
    private CompositeService compositeService;
    @Autowired
    public MyController(RemoteHousingService housingService, RemoteEmployeeService employeeService, CompositeService compositeService) {
        this.housingService = housingService;
        this.employeeService = employeeService;
        this.compositeService = compositeService;
    }

    @GetMapping("/emp/houseDetailEmp")
    @PreAuthorize(value = "hasAnyAuthority('EMP')")
    @ApiOperation(value = "Get current employee's House Detail", response = HouseDetailsEmp.class)
    public HouseDetailsEmp getHouseDetailEmp(@RequestHeader("Authorization") String token){
        String[] chunks = token.split("\\.");
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String payload = new String(decoder.decode(chunks[1]));
        JSONObject json = new JSONObject(payload);
        String empId = (String) json.get("employeeId");
        System.out.println("Current employee's id: " + empId);
        return compositeService.getHouseDetailEmp(empId);
    }
    @PreAuthorize(value = "hasAnyAuthority('EMP')")
    @GetMapping("/emp/getReportDetailsEmp")
    @ApiOperation(value = "Get all facility reports", response = Iterable.class)
    public List<ResponseReportEMP> getAllReports(){
        return compositeService.getAllReports();
    }
    @PreAuthorize(value = "hasAnyAuthority('EMP','HR')")
    @GetMapping("/hr/randomHouse")
    @ApiOperation(value = "Random assign a available house", response = Integer.class)
    public Integer assignHouse(){
        return compositeService.assignHouse();
    }
    @PreAuthorize(value = "hasAnyAuthority('EMP','HR')")
    @GetMapping("/hr/houseSummaryHr")
    @ApiOperation(value = "Get houses summary", response = Iterable.class)
    public List<HouseSummaryHr> houseSummary(){
        return compositeService.houseSummary();
    }
    @GetMapping("/hr/getReportDetailsHr")
    @PreAuthorize(value = "hasAnyAuthority('EMP','HR')")
    @ApiOperation(value = "Get house detail by houseId", response = HouseDetailHr.class)
    public HouseDetailHr getHouseDetailHr(@RequestParam Integer houseId){
        return compositeService.getHouseDetailHr(houseId);
    }
    }

