package com.example.compositeservice.domain.employeeEntity;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class Address {
    private String id;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String state;

    private String zipCode;
}
