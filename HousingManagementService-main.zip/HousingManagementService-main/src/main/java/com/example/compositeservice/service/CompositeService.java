package com.example.compositeservice.service;

import com.example.compositeservice.domain.employeeEntity.Employee;
import com.example.compositeservice.domain.employeeEntity.EmployeeSummaryDto;
import com.example.compositeservice.domain.housingEntity.ResponseLandlord;
import com.example.compositeservice.domain.housingEntity.ResponseReportEMP;
import com.example.compositeservice.domain.response.HouseDetailHr;
import com.example.compositeservice.domain.response.HouseDetailsEmp;
import com.example.compositeservice.domain.response.HouseSummaryHr;
import com.example.compositeservice.service.remote.RemoteEmployeeService;
import com.example.compositeservice.service.remote.RemoteHousingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CompositeService {
    private RemoteHousingService housingService;
    private RemoteEmployeeService employeeService;
    @Autowired
    public void setHousingService(RemoteHousingService housingService) {
        this.housingService = housingService;
    }
    @Autowired
    public void setUserService(RemoteEmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    public HouseDetailHr getHouseDetailHr(Integer houseId){
        List<Map<String,Object>> facilitySum = housingService.facilitySummary(houseId);

        List<ResponseReportEMP> reports =  getAllReports();
        List<EmployeeSummaryDto> employees =  employeeService.getEmployeesByHouseId(houseId);
        List<String> nameList = new ArrayList<>();
        for (EmployeeSummaryDto employee:employees){
           nameList.add( employee.getFullName());
        }
        List<ResponseReportEMP> filteredReports = new ArrayList<>();
        for (ResponseReportEMP report :reports){
            if(nameList.contains(report.getFullName())){
                filteredReports.add(report);
            }
        }

        return HouseDetailHr.builder().facilitiesInHouse(facilitySum).filteredReports(filteredReports).roommateInfo(employees).build();
        }

    public List<HouseSummaryHr> houseSummary(){
        List<HouseSummaryHr> houseSummary = new ArrayList<>();
        List<Integer> houses = new ArrayList<>(housingService.houseOccList().keySet());
        List<Employee> allEmployee = employeeService.getAllEmployee();
        Map<Integer, Integer> employCount = new HashMap<>();
        for (Employee employee : allEmployee) {
            if (employee.getHouseId() != null) {
                if (employCount.containsKey(employee.getHouseId())) {
                    employCount.put(employee.getHouseId(), employCount.get(employee.getHouseId()) + 1);
                } else {
                    employCount.put(employee.getHouseId(), 1);
                }}
        }
        for (int houseId :houses){
            String address =  housingService.getAddress(houseId);
            ResponseLandlord landlord = housingService.landlordInfo(houseId);
            Integer residents = employCount.getOrDefault(houseId, 0);
            houseSummary.add(HouseSummaryHr.builder().address(address).landlord(landlord).numOfResidents(residents).build());
        }
        return houseSummary;
    }
    public HouseDetailsEmp getHouseDetailEmp(String empId){
        Employee employee = employeeService.getById(empId);
        Integer houseId = employee.getHouseId();
        String address = housingService.getAddress(houseId);

        List<EmployeeSummaryDto> employees = employeeService.getEmployeesByHouseId(houseId);

        return HouseDetailsEmp.builder().address(address).roommateInfo(employees).build();
    }

    public List<ResponseReportEMP> getAllReports(){
        List<ResponseReportEMP> reports = housingService.viewAllReports();
        for(ResponseReportEMP report :reports){
           String fullnameRep = employeeService.getFullNameByEmployeeId(report.getAuthor());
           report.setFullName(fullnameRep);

           List<Map<String,Object>> details = report.getFacilityReportDetails();
           for(Map<String,Object> detail :details){
               String fullnameDet = employeeService.getFullNameByEmployeeId((String) detail.get("employee_id"));
               detail.put("fullname", fullnameDet);
           }
        }
        return reports;
    }

    public Integer assignHouse(){
        List<Employee> employlist= employeeService.getAllEmployee();
        Map<Integer, Integer> employCount = new HashMap<>();
        for (Employee employee : employlist) {
            if (employee.getHouseId() != null) {
                if (employCount.containsKey(employee.getHouseId())) {
                employCount.put(employee.getHouseId(), employCount.get(employee.getHouseId()) + 1);
                } else {
                employCount.put(employee.getHouseId(), 1);
            }}
        }
        Map<Integer, Integer> occMap = housingService.houseOccList();
        List<Integer> allHouses = new ArrayList<>(occMap.keySet());
        List<Integer> fullHouse = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : employCount.entrySet()) {
            int houseId = entry.getKey();
            int employeeCount = entry.getValue();
            int maxOccupancy = occMap.get(houseId);
            if (employeeCount == maxOccupancy) {
                fullHouse.add(houseId);
            }
        }
        allHouses.removeAll(fullHouse);
        Collections.shuffle(allHouses);
        return allHouses.get(0);
    }


}
