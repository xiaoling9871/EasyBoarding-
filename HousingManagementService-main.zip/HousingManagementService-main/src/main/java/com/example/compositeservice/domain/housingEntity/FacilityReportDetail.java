package com.example.compositeservice.domain.housingEntity;

import lombok.*;

import java.sql.Timestamp;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class FacilityReportDetail {

    private Integer id;


    private FacilityReport facilityReport;


    private String employeeId;


    private Timestamp lastModificationDate;


    private String comment;


    private Timestamp createDate;
}
