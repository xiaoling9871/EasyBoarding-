package com.example.compositeservice.domain.employeeEntity;

import lombok.Builder;
import lombok.Data;


import java.util.Date;

@Data
@Builder
public class VisaStatus {
    private String id;

    private String visaType;
    private Boolean activeFlag;

    private Date startDate;

    private Date endDate;
    private Date lastModifiedDate;
}
