package com.example.compositeservice.domain.employeeEntity;

import lombok.Builder;
import lombok.Data;


import java.util.Date;

@Data
@Builder
public class PersonalDocument {
    private String id;

    private String path;

    private String comment;

    private Date createDate;
}
