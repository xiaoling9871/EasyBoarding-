package com.example.compositeservice.domain.housingEntity;

import com.example.compositeservice.domain.housingEntity.Facility;
import com.example.compositeservice.domain.housingEntity.House;
import com.example.compositeservice.domain.housingEntity.Landlord;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResponseHouseDetail {
    House house;
    Landlord landlord;
    Facility facility;

}
