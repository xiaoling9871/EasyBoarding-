package com.example.compositeservice.domain.employeeEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Employee implements Serializable {
    private String id;
    private Integer userId;
    private String firstName;
    private String lastName;
    private String email;
    private String cellPhone;
    private String gender;
    private String SSN;
    private Date DOB;
    private DriverLicense driverLicense;
    private Integer houseId;


    private List<Contact> contactList;


    private List<Address> addressList;


    private List<VisaStatus> visaStatusList;


    private List<PersonalDocument> personalDocumentList;


    private List<SignedDocument> signedDocumentList;

    public Employee(EmployeeDto dto) {
        setId(dto.getId());
        setSSN(dto.getSSN());
        setDOB(dto.getDOB());
        setEmail(dto.getEmail());
        setUserId(dto.getUserId());
        setGender(dto.getGender());
        setHouseId(dto.getHouseId());
        setLastName(dto.getLastName());
        setFirstName(dto.getFirstName());
        setCellPhone(dto.getCellPhone());
        setAddressList(dto.getAddressList());
        setContactList(dto.getContactList());
        setVisaStatusList(dto.getVisaStatusList());
        setDriverLicense(DriverLicense.builder()
                .expirationDate(dto.getDriverLicenseExpiration())
                .licenseNumber(dto.getDriverLicenseNumber())
                .build());

    }
}
