package com.example.compositeservice.domain.housingEntity;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResponseAddHouseHr {

    private String address;
    private Integer maxOccupants;
    private String firstname;
    private String lastname;
    private String email;
    private String cellphone;
    private String type;
    private String description;
    private int quantity;


}

