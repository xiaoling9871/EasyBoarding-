package com.example.compositeservice.domain.housingEntity;

import lombok.*;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Facility {

    private Integer id;


    private House house;

    private String type;

    private String description ;

    private Integer quantity;


    private List<FacilityReport> facilityReports;
}
