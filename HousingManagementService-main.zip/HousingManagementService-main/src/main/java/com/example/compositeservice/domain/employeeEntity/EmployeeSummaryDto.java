package com.example.compositeservice.domain.employeeEntity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@ToString
@Getter
@Setter
public class EmployeeSummaryDto {
    String fullName;
    String phoneNumber;
    String email;
}
