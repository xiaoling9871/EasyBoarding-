package com.example.compositeservice.service.remote;

import com.example.compositeservice.domain.employeeEntity.Employee;
import com.example.compositeservice.domain.employeeEntity.EmployeeDto;
import com.example.compositeservice.domain.employeeEntity.EmployeePatchDto;
import com.example.compositeservice.domain.employeeEntity.EmployeeSummaryDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@FeignClient(value = "employee-service")
public interface RemoteEmployeeService {
    @GetMapping("/employee/house/{houseId}")
    public List<EmployeeSummaryDto> getEmployeesByHouseId(@PathVariable Integer houseId) ;

    @GetMapping("/employee/name/{employeeId}")
    public String getFullNameByEmployeeId(@PathVariable String employeeId) ;

    @PostMapping(value = "/employee/json")
    public Employee createEmployeeJson(@RequestBody EmployeeDto employeeDto);

    @PatchMapping("/employee/{employeeId}")
    public Employee updateEmployee(@RequestPart("driver-license") Optional<MultipartFile> driverLicense,
                                   @RequestPart("opt-receipt") Optional<MultipartFile>  optReceipt,
                                   @RequestPart("data") @Validated EmployeePatchDto changedFields,
                                   @PathVariable String employeeId) ;

    @GetMapping("/employee/all")
    public List<Employee> getAllEmployee() ;

    @GetMapping("/employee/user/{userId}")
    public String getEmployeeIdByUserId(@PathVariable Integer userId) ;

    @GetMapping("/employee/{id}")
    public Employee getById(@PathVariable String id) ;
}
