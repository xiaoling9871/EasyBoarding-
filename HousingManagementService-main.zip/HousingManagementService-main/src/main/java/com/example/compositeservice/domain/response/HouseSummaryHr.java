package com.example.compositeservice.domain.response;

import com.example.compositeservice.domain.housingEntity.Landlord;
import com.example.compositeservice.domain.housingEntity.ResponseLandlord;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HouseSummaryHr {
    String address;
    ResponseLandlord landlord;
    Integer numOfResidents;
}
